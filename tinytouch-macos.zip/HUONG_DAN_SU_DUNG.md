# 🌟 HƯỚNG DẪN CÀI ĐẶT & SỬ DỤNG THIẾT BỊ TINYTOUCH (macOS)

Chào mừng bạn đến với **tinyTouch** — Thiết bị xác thực cảm biến vân tay cao cấp mở khóa 1 chạm siêu tốc dành cho hệ điều hành **macOS** (MacBook, Mac mini, Mac Studio, iMac).

---

## 🎯 TÍNH NĂNG NỔI BẬT
* ⚡ **Mở khóa Mac 1 chạm:** Chạm nhẹ ngón tay để mở khóa màn hình ngay tức thì.
* 🔑 **Tự động điền mật khẩu:** Đăng nhập Apple Passwords, Keychain, Safari, 1Password, Bitwarden...
* 🛡️ **Phê duyệt quyền Admin:** Xác thực nhanh khi cài ứng dụng, phân quyền hệ thống hoặc lệnh `sudo` trong Terminal.
* 🔒 **Bảo mật phần cứng cấp quân sự:** Mã hóa phần cứng XTS-AES 256-bit chống trích xuất dữ liệu và khóa 2 lớp chống tráo cảm biến.
* 🌙 **Thiết kế Stealth Mode:** Đèn LED thông minh tự động tắt hoàn toàn khi ở chế độ chờ.

---

## 📋 YÊU CẦU HỆ THỐNG & CHUẨN BỊ

* Máy Mac chạy hệ điều hành macOS (Intel hoặc Apple Silicon M1/M2/M3/M4).
* Đã cài đặt **Python 3** (mặc định macOS đã có sẵn, hoặc cài qua `brew install python`).
* Cáp kết nối USB-C hoặc USB-A cắm thiết bị tinyTouch vào máy Mac.

---

## 🚀 QUY TRÌNH CÀI ĐẶT LẦN ĐẦU (CHỈ 2 PHÚT)

### 📌 Bước 1: Cắm thiết bị tinyTouch vào máy Mac
Cắm thiết bị vào cổng USB trên máy Mac của bạn.

---

### 📌 Bước 2: Mở Terminal và vào thư mục tinyTouch
1. Nhấn tổ hợp phím **`Command + Space`** $\rightarrow$ Gõ **`Terminal`** $\rightarrow$ Nhấn **Enter**.
2. Di chuyển vào thư mục chứa phần mềm tinyTouch bằng lệnh:
   ```bash
   cd /Volumes/VietBoss/code/tinyTouch
   ```
   *(Hoặc gõ `cd ` rồi kéo thả thư mục tinyTouch vào cửa sổ Terminal)*.

---

### 📌 Bước 3: Cài đặt tự động trọn gói (Khuyên dùng)
Chạy lệnh thiết lập tự động sau:
```bash
./tinytouch setup
```
> 💡 **Hệ thống sẽ tự động thực hiện từ A đến Z:**
> 1. Tự động khởi tạo **Môi trường ảo Python (`.venv`)** và cài đặt các thư viện cần thiết (`pyserial`, `cryptography`).
> 2. Tự động cài đặt **Dịch vụ chạy ngầm macOS Helper** (để tự động điền mật khẩu bất cứ khi nào bạn chạm tay).
> 3. Hướng dẫn bạn **quét đăng ký vân tay** (Chạm lần 1 $\rightarrow$ Nhấc tay $\rightarrow$ Chạm lần 2).
> 4. Lưu mật khẩu máy Mac vào chip bảo mật của thiết bị.

---

## 🛠️ CÁC THAO TÁC CÀI ĐẶT THỦ CÔNG (TÙY CHỌN)

Nếu bạn không chạy `./tinytouch setup` mà muốn tự cấu hình từng bước:

### 1. Khởi tạo môi trường ảo Python thủ công:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r software/macos-helper/requirements.txt
```

### 2. Đăng ký thêm vân tay (Slot 1 đến Slot 5):
```bash
./tinytouch enroll 1
```
*(Đổi số `1` thành `2`, `3`, `4`, `5` để đăng ký các ngón tay khác nhau)*.

### 3. Ghép nối mật khẩu mở khóa máy Mac:
```bash
./tinytouch pair
```

---

## 💡 CÁCH SỬ DỤNG HÀNG NGÀY

Bất cứ khi nào máy Mac của bạn hiển thị ô nhập mật khẩu:
1. Đặt ngón tay đã đăng ký lên cảm biến **tinyTouch**.
2. **Tín hiệu đèn LED:**
   * 🟢 **Đèn nháy Xanh lá:** Nhận diện đúng vân tay $\rightarrow$ Tự động điền mật khẩu và ấn Enter mở khóa ngay lập tức!
   * 🔴 **Đèn nháy Đỏ:** Vân tay không khớp hoặc đặt sai ngón $\rightarrow$ Đặt lại đúng ngón tay vào giữa cảm biến.
   * 🌑 **Đèn tắt hoàn toàn:** Trạng thái nghỉ sẵn sàng (không tốn điện, không gây chói mắt).

---

## 🔄 HƯỚNG DẪN CHUYỂN ĐỔI CHẾ ĐỘ (HID vs PIV)

tinyTouch hỗ trợ 2 chế độ hoạt động linh hoạt, bạn có thể chuyển đổi bất cứ lúc nào:

### 1. Chế độ HID (Bàn phím tự động gõ — ⭐ Khuyên Dùng)
* **Ưu điểm:** Tự động điền mật khẩu ở **mọi nơi 100%** (Màn hình khóa, Apple Passwords, Cài đặt ứng dụng Admin, Keychain, Safari, Terminal...).
* **Cách chuyển:**
  ```bash
  ./tinytouch mode hid
  ```
  *(Khi Terminal yêu cầu `Touch the fingerprint sensor now`, hãy chạm ngón tay đã đăng ký vào cảm biến để xác nhận)*.
* **Sau khi chuyển xong:** Rút cáp USB ra cắm lại, rồi gõ `./tinytouch test` để kiểm tra.

---

### 2. Chế độ PIV (Smart Card chuẩn Apple)
* **Ưu điểm:** Máy Mac nhận diện tinyTouch là Thẻ thông minh SmartCard bảo mật, xác thực qua chứng chỉ mã hóa mà không truyền chuỗi mật khẩu văn bản.
* **Hạn chế:** Chỉ hỗ trợ mở khóa màn hình Mac và lệnh `sudo` trong Terminal.
* **Cách chuyển:**
  ```bash
  ./tinytouch mode piv
  ```
  *(Chạm ngón tay đã đăng ký để xác nhận chuyển đổi)*.

---

## 🖐️ TÍNH NĂNG ĐẶC BIỆT: GÁN MỖI NGÓN TAY MỘT MẬT KHẨU KHÁC NHAU

Ở chế độ **HID Mode**, tinyTouch cho phép bạn biến 5 ngón tay thành 5 "chìa khóa" mở 5 tài khoản khác nhau:

### 🌟 Ví dụ cách dùng:
* 👆 **Ngón trỏ (Slot 1):** Mật khẩu máy Mac (đăng nhập máy).
* 🖕 **Ngón giữa (Slot 2):** Master Password của 1Password / Bitwarden / Apple Passwords.
* 💍 **Ngón áp út (Slot 3):** Mật khẩu tài khoản Email / Công ty / VPN.
* 🤙 **Ngón cái (Slot 4):** Mật khẩu Server / SSH / GitHub token.
* 🖐️ **Ngón út (Slot 5):** Mật khẩu ví tiền điện tử (Crypto) hoặc ghi chú bảo mật.

### ⚙️ Các lệnh thiết lập:
1. **Xem danh sách 5 khe vân tay:**
   ```bash
   ./tinytouch slots
   ```
2. **Cài mật khẩu cho từng ngón:**
   ```bash
   ./tinytouch set-password 1    # Cài mật khẩu cho ngón 1
   ./tinytouch set-password 2    # Cài mật khẩu cho ngón 2
   ./tinytouch set-password 3    # Cài mật khẩu cho ngón 3
   ```
3. **Xóa mật khẩu riêng của 1 ngón (quay về mật khẩu mặc định):**
   ```bash
   ./tinytouch clear-password 2
   ```

---

## 📖 BẢNG TRA CỨU CÁC LỆNH QUẢN LÝ THƯỜNG DÙNG

| Thao tác | Câu lệnh trong Terminal (Lưu ý có dấu `./` ở đầu) |
| :--- | :--- |
| **Cài đặt trọn gói thiết bị** | `./tinytouch setup` |
| **Chuyển sang chế độ tự gõ pass (Khuyên dùng)** | `./tinytouch mode hid` |
| **Chuyển sang chế độ SmartCard** | `./tinytouch mode piv` |
| **Xem 5 khe vân tay & Mật khẩu** | `./tinytouch slots` |
| **Gán mật khẩu riêng cho ngón** | `./tinytouch set-password <1-5>` |
| **Xóa mật khẩu riêng của ngón** | `./tinytouch clear-password <1-5>` |
| **Kiểm tra trạng thái thiết bị** | `./tinytouch status` |
| **Thử nghiệm gõ mật khẩu** | `./tinytouch test` |
| **Đăng ký thêm ngón tay** | `./tinytouch enroll <1-5>` *(Ví dụ: `./tinytouch enroll 2`)* |
| **Đổi mật khẩu máy Mac mặc định** | `./tinytouch pair` |
| **Xóa 1 ngón tay** | `./tinytouch delete <1-5>` |
| **Khôi phục cài đặt gốc** | `./tinytouch factory-reset` |
| **Xem nhật ký hoạt động** | `./tinytouch logs` |

---

## ❓ CÂU HỎI THƯỜNG GẶP & XỬ LÝ SỰ CỐ

#### 1. Lỗi `zsh: no such file or directory: /tinytouch`?
> 👉 **Nguyên nhân:** Bạn đang gõ thiếu dấu chấm `.` ở đầu hoặc chưa `cd` vào đúng thư mục tinyTouch.
> 👉 **Cách sửa:** Gõ đúng lệnh:
> ```bash
> cd /Volumes/VietBoss/code/tinyTouch
> ./tinytouch status
> ```

#### 2. Tôi đổi mật khẩu máy Mac thì cần làm gì?
> 👉 Chỉ cần cắm tinyTouch vào máy Mac và chạy lại lệnh:
> ```bash
> ./tinytouch pair
> ```
> Nhập mật khẩu mới là thiết bị sẽ tự động đồng bộ.

#### 3. Thiết bị có lưu mật khẩu của tôi an toàn không?
> 🛡️ **Tuyệt đối an toàn!** Mật khẩu được mã hóa phần cứng chuẩn **XTS-AES 256-bit** với khóa riêng biệt. Kể cả khi có người tháo thiết bị ra cũng không thể giải mã hay đọc trộm được mật khẩu.
EOF
